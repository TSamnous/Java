package lab9;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import javax.swing.ImageIcon;
import javax.swing.JSplitPane;
import javax.swing.JTextPane;
import javax.swing.border.EtchedBorder;

public class lab9 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					lab9 frame = new lab9();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public lab9() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 989, 1092);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 64));
		panel.setBounds(10, 0, 955, 213);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Samson Andrew Fernandez");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(32, 33, 348, 57);
		panel.add(lblNewLabel);
		
		JTextArea txtrToSecureA = new JTextArea();
		txtrToSecureA.setLineWrap(true);
		txtrToSecureA.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtrToSecureA.setText("To secure a challenging position where I can effectively contribute my skills as software professional for the growth of the organization and myself.");
		txtrToSecureA.setBackground(new Color(0, 0, 64));
		txtrToSecureA.setForeground(new Color(255, 255, 255));
		txtrToSecureA.setBounds(32, 100, 728, 62);
		panel.add(txtrToSecureA);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\DELL\\Downloads\\formal_img_jas (3).jpeg"));
		lblNewLabel_1.setBounds(781, 10, 152, 180);
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 128, 192));
		panel_1.setBounds(10, 212, 955, 62);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\DELL\\Downloads\\pngfind.com-mail-png-transparent-6709617 (1) (1).png"));
		lblNewLabel_2.setBounds(10, 10, 45, 42);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("samson.fernandez@mca.christuniversity.in");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBounds(52, 10, 318, 31);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2_1 = new JLabel("");
		lblNewLabel_2_1.setIcon(new ImageIcon("C:\\Users\\DELL\\Downloads\\pngfind.com-location-icon-png-1829110 (1).png"));
		lblNewLabel_2_1.setBounds(430, 10, 37, 42);
		panel_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("Bangalore");
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_3_1.setBounds(465, 10, 93, 31);
		panel_1.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("");
		lblNewLabel_2_1_1.setIcon(new ImageIcon("C:\\Users\\DELL\\Downloads\\pngfind.com-icon-png-images-1504296 (1).png"));
		lblNewLabel_2_1_1.setBounds(752, 10, 37, 42);
		panel_1.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("9745521159");
		lblNewLabel_3_1_1.setForeground(Color.WHITE);
		lblNewLabel_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_3_1_1.setBounds(792, 10, 123, 31);
		panel_1.add(lblNewLabel_3_1_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 271, 955, 667);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(0, 0, 64));
		panel_3.setBounds(0, 0, 497, 667);
		panel_2.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Educational Background");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_4.setBounds(28, 0, 277, 42);
		panel_3.add(lblNewLabel_4);
		
		JTextArea txtrChristdeemedTo = new JTextArea();
		txtrChristdeemedTo.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtrChristdeemedTo.setBackground(new Color(0, 0, 64));
		txtrChristdeemedTo.setForeground(new Color(255, 255, 255));
		txtrChristdeemedTo.setText("Christ (Deemed To Be University), Bangalore");
		txtrChristdeemedTo.setBounds(84, 73, 355, 31);
		panel_3.add(txtrChristdeemedTo);
		
		JLabel lblNewLabel_4_1 = new JLabel("Post Graduation");
		lblNewLabel_4_1.setForeground(Color.WHITE);
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4_1.setBounds(28, 36, 277, 42);
		panel_3.add(lblNewLabel_4_1);
		
		JTextArea txtrCgpa = new JTextArea();
		txtrCgpa.setText("CGPA - 3.89/4.00");
		txtrCgpa.setForeground(Color.WHITE);
		txtrCgpa.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtrCgpa.setBackground(new Color(0, 0, 64));
		txtrCgpa.setBounds(84, 100, 266, 31);
		panel_3.add(txtrCgpa);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("Under Graduation");
		lblNewLabel_4_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4_1_1.setBounds(28, 127, 277, 42);
		panel_3.add(lblNewLabel_4_1_1);
		
		JTextArea txtrStXaviersCollege = new JTextArea();
		txtrStXaviersCollege.setText("Govt.Brennan College Thalassery, Kerala");
		txtrStXaviersCollege.setForeground(Color.WHITE);
		txtrStXaviersCollege.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtrStXaviersCollege.setBackground(new Color(0, 0, 64));
		txtrStXaviersCollege.setBounds(84, 168, 355, 31);
		panel_3.add(txtrStXaviersCollege);
		
		JTextArea txtrCgpa_2 = new JTextArea();
		txtrCgpa_2.setText("CGPA - 8.85/10.00");
		txtrCgpa_2.setForeground(Color.WHITE);
		txtrCgpa_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtrCgpa_2.setBackground(new Color(0, 0, 64));
		txtrCgpa_2.setBounds(84, 195, 266, 31);
		panel_3.add(txtrCgpa_2);
		
		JLabel lblNewLabel_4_1_1_1 = new JLabel("Higher School Certificate");
		lblNewLabel_4_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4_1_1_1.setBounds(28, 221, 277, 42);
		panel_3.add(lblNewLabel_4_1_1_1);
		
		JTextArea txtrGulmohurHighSchool = new JTextArea();
		txtrGulmohurHighSchool.setText("St.Joseph's Higher Secondary School thalasseryKerala");
		txtrGulmohurHighSchool.setForeground(Color.WHITE);
		txtrGulmohurHighSchool.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtrGulmohurHighSchool.setBackground(new Color(0, 0, 64));
		txtrGulmohurHighSchool.setBounds(84, 266, 390, 31);
		panel_3.add(txtrGulmohurHighSchool);
		
		JTextArea txtrCgpa_2_1 = new JTextArea();
		txtrCgpa_2_1.setText("Percent - 84.86%");
		txtrCgpa_2_1.setForeground(Color.WHITE);
		txtrCgpa_2_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtrCgpa_2_1.setBackground(new Color(0, 0, 64));
		txtrCgpa_2_1.setBounds(84, 294, 266, 31);
		panel_3.add(txtrCgpa_2_1);
		
		JLabel lblNewLabel_4_3 = new JLabel("Technical Skills");
		lblNewLabel_4_3.setForeground(Color.WHITE);
		lblNewLabel_4_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_4_3.setBounds(28, 335, 277, 42);
		panel_3.add(lblNewLabel_4_3);
		
		JLabel lblNewLabel_4_1_2 = new JLabel("Programming Skills - Java, C, C++, Python");
		lblNewLabel_4_1_2.setForeground(Color.WHITE);
		lblNewLabel_4_1_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4_1_2.setBounds(28, 377, 411, 42);
		panel_3.add(lblNewLabel_4_1_2);
		
		JLabel lblNewLabel_4_1_2_1 = new JLabel("Web Designing Languages - HTML, CSS, Bootstrap, JS");
		lblNewLabel_4_1_2_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4_1_2_1.setBounds(28, 410, 446, 42);
		panel_3.add(lblNewLabel_4_1_2_1);
		
		JLabel lblNewLabel_4_1_2_1_1 = new JLabel("Operating System - Windows");
		lblNewLabel_4_1_2_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4_1_2_1_1.setBounds(28, 442, 446, 42);
		panel_3.add(lblNewLabel_4_1_2_1_1);
		
		JLabel lblNewLabel_4_1_2_1_1_1 = new JLabel("Database - MySQL, MS Access, DBMS");
		lblNewLabel_4_1_2_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_2_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4_1_2_1_1_1.setBounds(28, 474, 446, 42);
		panel_3.add(lblNewLabel_4_1_2_1_1_1);
		
		JPanel panel_3_1 = new JPanel();
		panel_3_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_3_1.setLayout(null);
		panel_3_1.setBackground(new Color(0, 0, 64));
		panel_3_1.setBounds(495, 0, 460, 750);
		panel_2.add(panel_3_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("Skills");
		lblNewLabel_4_2.setForeground(Color.WHITE);
		lblNewLabel_4_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_4_2.setBounds(28, 28, 277, 42);
		panel_3_1.add(lblNewLabel_4_2);
		
		JTextPane txtpnGoodOrganisationalSkills = new JTextPane();
		txtpnGoodOrganisationalSkills.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnGoodOrganisationalSkills.setText("Good organisational skills");
		txtpnGoodOrganisationalSkills.setForeground(new Color(255, 255, 255));
		txtpnGoodOrganisationalSkills.setBackground(new Color(0, 128, 255));
		txtpnGoodOrganisationalSkills.setBounds(28, 80, 207, 31);
		panel_3_1.add(txtpnGoodOrganisationalSkills);
		
		JTextPane txtpnPunctual = new JTextPane();
		txtpnPunctual.setText("Punctual");
		txtpnPunctual.setForeground(Color.WHITE);
		txtpnPunctual.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnPunctual.setBackground(new Color(0, 128, 255));
		txtpnPunctual.setBounds(243, 80, 207, 31);
		panel_3_1.add(txtpnPunctual);
		
		JTextPane txtpnEagerToLearn = new JTextPane();
		txtpnEagerToLearn.setText("Confident");
		txtpnEagerToLearn.setForeground(Color.WHITE);
		txtpnEagerToLearn.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnEagerToLearn.setBackground(new Color(0, 128, 255));
		txtpnEagerToLearn.setBounds(28, 131, 207, 31);
		panel_3_1.add(txtpnEagerToLearn);
		
		JTextPane txtpnTimeManagementSkills = new JTextPane();
		txtpnTimeManagementSkills.setText("Time Management skills");
		txtpnTimeManagementSkills.setForeground(Color.WHITE);
		txtpnTimeManagementSkills.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnTimeManagementSkills.setBackground(new Color(0, 128, 255));
		txtpnTimeManagementSkills.setBounds(243, 131, 207, 31);
		panel_3_1.add(txtpnTimeManagementSkills);
		
		JTextPane txtpnGoodCommunicationAd = new JTextPane();
		txtpnGoodCommunicationAd.setText("Good communication and listening skills");
		txtpnGoodCommunicationAd.setForeground(Color.WHITE);
		txtpnGoodCommunicationAd.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnGoodCommunicationAd.setBackground(new Color(0, 128, 255));
		txtpnGoodCommunicationAd.setBounds(28, 181, 422, 31);
		panel_3_1.add(txtpnGoodCommunicationAd);
		
		JLabel lblNewLabel_4_2_1 = new JLabel("Area Of Interest");
		lblNewLabel_4_2_1.setForeground(Color.WHITE);
		lblNewLabel_4_2_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_4_2_1.setBounds(28, 253, 277, 42);
		panel_3_1.add(lblNewLabel_4_2_1);
		
		JTextPane txtpnJava = new JTextPane();
		txtpnJava.setText("Java");
		txtpnJava.setForeground(Color.WHITE);
		txtpnJava.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnJava.setBackground(new Color(0, 128, 255));
		txtpnJava.setBounds(28, 305, 91, 31);
		panel_3_1.add(txtpnJava);
		
		JTextPane txtpnPython = new JTextPane();
		txtpnPython.setText("Python");
		txtpnPython.setForeground(Color.WHITE);
		txtpnPython.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnPython.setBackground(new Color(0, 128, 255));
		txtpnPython.setBounds(178, 305, 91, 31);
		panel_3_1.add(txtpnPython);
		
		JTextPane txtpnPhp = new JTextPane();
		txtpnPhp.setText("PHP");
		txtpnPhp.setForeground(Color.WHITE);
		txtpnPhp.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnPhp.setBackground(new Color(0, 128, 255));
		txtpnPhp.setBounds(335, 305, 91, 31);
		panel_3_1.add(txtpnPhp);
		
		JTextPane txtpnMysql = new JTextPane();
		txtpnMysql.setText("MySQL");
		txtpnMysql.setForeground(Color.WHITE);
		txtpnMysql.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnMysql.setBackground(new Color(0, 128, 255));
		txtpnMysql.setBounds(28, 357, 91, 31);
		panel_3_1.add(txtpnMysql);
		
		JTextPane txtpnNetwork = new JTextPane();
		txtpnNetwork.setText("Network");
		txtpnNetwork.setForeground(Color.WHITE);
		txtpnNetwork.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnNetwork.setBackground(new Color(0, 128, 255));
		txtpnNetwork.setBounds(178, 357, 91, 31);
		panel_3_1.add(txtpnNetwork);
		
		JTextPane txtpnHtmlcss = new JTextPane();
		txtpnHtmlcss.setText("HTML/CSS");
		txtpnHtmlcss.setForeground(Color.WHITE);
		txtpnHtmlcss.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnHtmlcss.setBackground(new Color(0, 128, 255));
		txtpnHtmlcss.setBounds(335, 357, 91, 31);
		panel_3_1.add(txtpnHtmlcss);
		
		JLabel lblNewLabel_4_2_1_1 = new JLabel("Languages Known");
		lblNewLabel_4_2_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_4_2_1_1.setBounds(28, 423, 277, 42);
		panel_3_1.add(lblNewLabel_4_2_1_1);
		
		JTextPane txtpnEnglish = new JTextPane();
		txtpnEnglish.setText("English");
		txtpnEnglish.setForeground(Color.WHITE);
		txtpnEnglish.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnEnglish.setBackground(new Color(0, 128, 255));
		txtpnEnglish.setBounds(28, 466, 91, 31);
		panel_3_1.add(txtpnEnglish);
		
		JTextPane txtpnHindi = new JTextPane();
		txtpnHindi.setText("Hindi");
		txtpnHindi.setForeground(Color.WHITE);
		txtpnHindi.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnHindi.setBackground(new Color(0, 128, 255));
		txtpnHindi.setBounds(335, 466, 91, 31);
		panel_3_1.add(txtpnHindi);
		
		JTextPane txtpnPunjabi = new JTextPane();
		txtpnPunjabi.setText("konkani");
		txtpnPunjabi.setForeground(Color.WHITE);
		txtpnPunjabi.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtpnPunjabi.setBackground(new Color(0, 128, 255));
		txtpnPunjabi.setBounds(178, 466, 91, 31);
		panel_3_1.add(txtpnPunjabi);
	}
}